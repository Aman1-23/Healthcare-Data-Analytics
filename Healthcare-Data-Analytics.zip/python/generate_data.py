import pandas as pd
import numpy as np

# Generates dataset
print("Dataset already generated in /data folder")
