import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv('../data/healthcare_data.csv')

print(df.head())
print(df.describe())

disease = df['Disease'].value_counts()
print(disease)

revenue = df.groupby('Hospital')['Bill_Amount'].sum()
print(revenue)

df['Stay_Days'] = (pd.to_datetime(df['Discharge_Date']) - pd.to_datetime(df['Admission_Date'])).dt.days

print("Average Stay:", df['Stay_Days'].mean())

disease.plot(kind='bar')
plt.title("Disease Distribution")
plt.show()

revenue.plot(kind='bar')
plt.title("Hospital Revenue")
plt.show()
