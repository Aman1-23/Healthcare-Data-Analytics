# Healthcare Data Analytics Project

## Overview
Analyzed 10,000+ healthcare records using SQL, Python, and Power BI.

## Tools Used
- Python (Pandas, NumPy)
- SQL
- Power BI
- Excel

## Key Insights
- Disease trends and distribution
- Hospital revenue analysis
- Patient stay duration

## Outcome
Improved reporting efficiency and enabled data-driven decisions.
