SELECT COUNT(*) FROM healthcare;

SELECT Disease, COUNT(*) AS Total
FROM healthcare
GROUP BY Disease;

SELECT Hospital, SUM(Bill_Amount) AS Revenue
FROM healthcare
GROUP BY Hospital;

SELECT AVG(Bill_Amount) FROM healthcare;

SELECT Patient_ID,
DATEDIFF(Discharge_Date, Admission_Date) AS Stay_Days
FROM healthcare;
